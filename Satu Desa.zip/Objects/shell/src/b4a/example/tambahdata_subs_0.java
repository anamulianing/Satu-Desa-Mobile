package b4a.example;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class tambahdata_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,38);
if (RapidSub.canDelegate("activity_create")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 38;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(32);
 BA.debugLineNum = 40;BA.debugLine="Activity.LoadLayout(\"TambahPersyaratan\")";
Debug.ShouldStop(128);
tambahdata.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("TambahPersyaratan")),tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 42;BA.debugLine="pnlPersyaratan.Visible = True";
Debug.ShouldStop(512);
tambahdata.mostCurrent._pnlpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 43;BA.debugLine="pnlTambahPersyaratan.Visible = False";
Debug.ShouldStop(1024);
tambahdata.mostCurrent._pnltambahpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 45;BA.debugLine="showItem";
Debug.ShouldStop(4096);
_showitem();
 BA.debugLineNum = 47;BA.debugLine="xclv.DefaultTextColor = Colors.Black";
Debug.ShouldStop(16384);
tambahdata.mostCurrent._xclv.setField ("_defaulttextcolor",tambahdata.mostCurrent.__c.getField(false,"Colors").getField(true,"Black"));
 BA.debugLineNum = 49;BA.debugLine="fd.TextColor = Colors.Black";
Debug.ShouldStop(65536);
tambahdata.mostCurrent._fd.setField ("TextColor",tambahdata.mostCurrent.__c.getField(false,"Colors").getField(true,"Black"));
 BA.debugLineNum = 50;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,56);
if (RapidSub.canDelegate("activity_pause")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 56;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(8388608);
 BA.debugLineNum = 58;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,52);
if (RapidSub.canDelegate("activity_resume")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","activity_resume");}
 BA.debugLineNum = 52;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(524288);
 BA.debugLineNum = 54;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnback_click() throws Exception{
try {
		Debug.PushSubsStack("btnBack_Click (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,116);
if (RapidSub.canDelegate("btnback_click")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","btnback_click");}
 BA.debugLineNum = 116;BA.debugLine="Private Sub btnBack_Click";
Debug.ShouldStop(524288);
 BA.debugLineNum = 117;BA.debugLine="pnlPersyaratan.Visible = True";
Debug.ShouldStop(1048576);
tambahdata.mostCurrent._pnlpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 118;BA.debugLine="pnlTambahPersyaratan.Visible = False";
Debug.ShouldStop(2097152);
tambahdata.mostCurrent._pnltambahpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 119;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnpict_click() throws Exception{
try {
		Debug.PushSubsStack("btnPict_Click (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,126);
if (RapidSub.canDelegate("btnpict_click")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","btnpict_click");}
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 126;BA.debugLine="Private Sub btnPict_Click";
Debug.ShouldStop(536870912);
 BA.debugLineNum = 127;BA.debugLine="Dim i As Int";
Debug.ShouldStop(1073741824);
_i = RemoteObject.createImmutable(0);Debug.locals.put("i", _i);
 BA.debugLineNum = 129;BA.debugLine="fd.FilePath = File.DirRootExternal";
Debug.ShouldStop(1);
tambahdata.mostCurrent._fd.runMethod(true,"setFilePath",tambahdata.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirRootExternal"));
 BA.debugLineNum = 130;BA.debugLine="i = fd.Show(\"Choose File\", \"Yes\", \"\", \"Cancel\", N";
Debug.ShouldStop(2);
_i = tambahdata.mostCurrent._fd.runMethod(true,"Show",(Object)(BA.ObjectToCharSequence("Choose File")),(Object)(BA.ObjectToString("Yes")),(Object)(BA.ObjectToString("")),(Object)(BA.ObjectToString("Cancel")),tambahdata.mostCurrent.activityBA,(Object)((tambahdata.mostCurrent.__c.getField(false,"Null"))));Debug.locals.put("i", _i);
 BA.debugLineNum = 131;BA.debugLine="If i = DialogResponse.POSITIVE Then";
Debug.ShouldStop(4);
if (RemoteObject.solveBoolean("=",_i,BA.numberCast(double.class, tambahdata.mostCurrent.__c.getField(false,"DialogResponse").getField(true,"POSITIVE")))) { 
 BA.debugLineNum = 132;BA.debugLine="lblPilihFile.Text = fd.ChosenName";
Debug.ShouldStop(8);
tambahdata.mostCurrent._lblpilihfile.runMethod(true,"setText",BA.ObjectToCharSequence(tambahdata.mostCurrent._fd.runMethod(true,"getChosenName")));
 };
 BA.debugLineNum = 134;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnsave_click() throws Exception{
try {
		Debug.PushSubsStack("btnSave_Click (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,136);
if (RapidSub.canDelegate("btnsave_click")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","btnsave_click");}
 BA.debugLineNum = 136;BA.debugLine="Private Sub btnSave_Click";
Debug.ShouldStop(128);
 BA.debugLineNum = 137;BA.debugLine="If txtPersyaratan.Text = \"\" Then";
Debug.ShouldStop(256);
if (RemoteObject.solveBoolean("=",tambahdata.mostCurrent._txtpersyaratan.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 138;BA.debugLine="MsgboxAsync(\"Masukkan Persyaratan\", \"Info\")";
Debug.ShouldStop(512);
tambahdata.mostCurrent.__c.runVoidMethod ("MsgboxAsync",(Object)(BA.ObjectToCharSequence("Masukkan Persyaratan")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Info"))),tambahdata.processBA);
 BA.debugLineNum = 139;BA.debugLine="Return";
Debug.ShouldStop(1024);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 142;BA.debugLine="If lblPilihFile.Text = \"\" Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",tambahdata.mostCurrent._lblpilihfile.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 143;BA.debugLine="MsgboxAsync(\"Tidak Ada File yang Dipilih\", \"Info";
Debug.ShouldStop(16384);
tambahdata.mostCurrent.__c.runVoidMethod ("MsgboxAsync",(Object)(BA.ObjectToCharSequence("Tidak Ada File yang Dipilih")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Info"))),tambahdata.processBA);
 BA.debugLineNum = 144;BA.debugLine="Return";
Debug.ShouldStop(32768);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 147;BA.debugLine="If btnSave.Text = \"Simpan\" Then";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean("=",tambahdata.mostCurrent._btnsave.runMethod(true,"getText"),BA.ObjectToString("Simpan"))) { 
 BA.debugLineNum = 149;BA.debugLine="ModulKoneksi.koneksi";
Debug.ShouldStop(1048576);
tambahdata.mostCurrent._modulkoneksi.runVoidMethod ("_koneksi" /*RemoteObject*/ ,tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 151;BA.debugLine="ModulKoneksi.ResultS = ModulKoneksi.MHandler.Que";
Debug.ShouldStop(4194304);
tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/  = RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("mysql.mysqlhandler.ResultSetWrapper"), tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runMethod(false,"Query",(Object)(RemoteObject.concat(RemoteObject.createImmutable("SELECT * FROM tb_persyaratan WHERE nama_persyaratan='"),tambahdata.mostCurrent._txtpersyaratan.runMethod(true,"getText"),RemoteObject.createImmutable("'")))));
 BA.debugLineNum = 152;BA.debugLine="If ModulKoneksi.ResultS.RowCount > 0 Then";
Debug.ShouldStop(8388608);
if (RemoteObject.solveBoolean(">",tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"RowCount"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 153;BA.debugLine="MsgboxAsync(\"Persyaratan sudah tersedia\", \"Info";
Debug.ShouldStop(16777216);
tambahdata.mostCurrent.__c.runVoidMethod ("MsgboxAsync",(Object)(BA.ObjectToCharSequence("Persyaratan sudah tersedia")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Info"))),tambahdata.processBA);
 BA.debugLineNum = 154;BA.debugLine="txtPersyaratan.Text = \"\"";
Debug.ShouldStop(33554432);
tambahdata.mostCurrent._txtpersyaratan.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 155;BA.debugLine="ModulKoneksi.MHandler.Close";
Debug.ShouldStop(67108864);
tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runVoidMethod ("Close");
 BA.debugLineNum = 156;BA.debugLine="Return";
Debug.ShouldStop(134217728);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 159;BA.debugLine="simpanBlob";
Debug.ShouldStop(1073741824);
_simpanblob();
 BA.debugLineNum = 161;BA.debugLine="ModulKoneksi.MHandler.Exec(\"INSERT INTO tb_persy";
Debug.ShouldStop(1);
tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runVoidMethod ("Exec",(Object)(RemoteObject.concat(RemoteObject.createImmutable("INSERT INTO tb_persyaratan VALUE('"),tambahdata.mostCurrent._txtpersyaratan.runMethod(true,"getText"),RemoteObject.createImmutable("', '"),tambahdata.mostCurrent._imgstr,RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 163;BA.debugLine="tampilanAwal";
Debug.ShouldStop(4);
_tampilanawal();
 BA.debugLineNum = 165;BA.debugLine="ModulKoneksi.MHandler.Close";
Debug.ShouldStop(16);
tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runVoidMethod ("Close");
 };
 BA.debugLineNum = 168;BA.debugLine="End Sub";
Debug.ShouldStop(128);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btntambahdata_click() throws Exception{
try {
		Debug.PushSubsStack("btnTambahData_Click (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,111);
if (RapidSub.canDelegate("btntambahdata_click")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","btntambahdata_click");}
 BA.debugLineNum = 111;BA.debugLine="Private Sub btnTambahData_Click";
Debug.ShouldStop(16384);
 BA.debugLineNum = 112;BA.debugLine="pnlPersyaratan.Visible = False";
Debug.ShouldStop(32768);
tambahdata.mostCurrent._pnlpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 113;BA.debugLine="pnlTambahPersyaratan.Visible = True";
Debug.ShouldStop(65536);
tambahdata.mostCurrent._pnltambahpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 114;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _filterlist() throws Exception{
try {
		Debug.PushSubsStack("FilterList (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,86);
if (RapidSub.canDelegate("filterlist")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","filterlist");}
int _i = 0;
RemoteObject _p = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
 BA.debugLineNum = 86;BA.debugLine="Sub FilterList";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 87;BA.debugLine="ModulKoneksi.koneksi";
Debug.ShouldStop(4194304);
tambahdata.mostCurrent._modulkoneksi.runVoidMethod ("_koneksi" /*RemoteObject*/ ,tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 89;BA.debugLine="xclv.Clear";
Debug.ShouldStop(16777216);
tambahdata.mostCurrent._xclv.runVoidMethod ("_clear");
 BA.debugLineNum = 90;BA.debugLine="ModulKoneksi.ResultS = ModulKoneksi.MHandler.Quer";
Debug.ShouldStop(33554432);
tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/  = RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("mysql.mysqlhandler.ResultSetWrapper"), tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runMethod(false,"Query",(Object)(RemoteObject.concat(RemoteObject.createImmutable("SELECT * FROM tb_persyaratan WHERE nama_persyaratan LIKE '%"),tambahdata.mostCurrent._search.runMethod(true,"getText"),RemoteObject.createImmutable("%' ORDER BY id_persyaratan ASC")))));
 BA.debugLineNum = 92;BA.debugLine="For i = 0 To ModulKoneksi.ResultS.RowCount - 1";
Debug.ShouldStop(134217728);
{
final int step4 = 1;
final int limit4 = RemoteObject.solve(new RemoteObject[] {tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"RowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step4 > 0 && _i <= limit4) || (step4 < 0 && _i >= limit4) ;_i = ((int)(0 + _i + step4))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 93;BA.debugLine="Dim p As Panel";
Debug.ShouldStop(268435456);
_p = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");Debug.locals.put("p", _p);
 BA.debugLineNum = 94;BA.debugLine="p = xui.CreatePanel(\"\")";
Debug.ShouldStop(536870912);
_p = RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.PanelWrapper"), tambahdata.mostCurrent._xui.runMethod(false,"CreatePanel",tambahdata.processBA,(Object)(RemoteObject.createImmutable(""))).getObject());Debug.locals.put("p", _p);
 BA.debugLineNum = 95;BA.debugLine="p.Color = Colors.Transparent";
Debug.ShouldStop(1073741824);
_p.runVoidMethod ("setColor",tambahdata.mostCurrent.__c.getField(false,"Colors").getField(true,"Transparent"));
 BA.debugLineNum = 96;BA.debugLine="p.LoadLayout(\"Item\")";
Debug.ShouldStop(-2147483648);
_p.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("Item")),tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 97;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, xclv.AsView.Width,";
Debug.ShouldStop(1);
_p.runVoidMethod ("SetLayoutAnimated",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(tambahdata.mostCurrent._xclv.runMethod(false,"_asview").runMethod(true,"getWidth")),(Object)(tambahdata.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))));
 BA.debugLineNum = 98;BA.debugLine="lblpersyaratan.Text = (\"Nama Persyaratan : \" & M";
Debug.ShouldStop(2);
tambahdata.mostCurrent._lblpersyaratan.runMethod(true,"setText",BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("Nama Persyaratan : "),tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("nama_persyaratan")))))));
 BA.debugLineNum = 99;BA.debugLine="lblfile.Text = (\"File : \" & ModulKoneksi.ResultS";
Debug.ShouldStop(4);
tambahdata.mostCurrent._lblfile.runMethod(true,"setText",BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("File : "),tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("file_persyaratan")))))));
 BA.debugLineNum = 100;BA.debugLine="Button1.Text  = (ModulKoneksi.ResultS.GetString2";
Debug.ShouldStop(8);
tambahdata.mostCurrent._button1.runMethod(true,"setText",BA.ObjectToCharSequence((tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("id_persyaratan"))))));
 BA.debugLineNum = 101;BA.debugLine="xclv.Add(p, \"\")";
Debug.ShouldStop(16);
tambahdata.mostCurrent._xclv.runVoidMethod ("_add",RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.B4XViewWrapper"), _p.getObject()),(Object)((RemoteObject.createImmutable(""))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 104;BA.debugLine="ModulKoneksi.MHandler.Close";
Debug.ShouldStop(128);
tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runVoidMethod ("Close");
 BA.debugLineNum = 105;BA.debugLine="End Sub";
Debug.ShouldStop(256);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 12;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 16;BA.debugLine="Dim xui As XUI";
tambahdata.mostCurrent._xui = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper.XUI");
 //BA.debugLineNum = 17;BA.debugLine="Private pnlTambahPersyaratan As Panel";
tambahdata.mostCurrent._pnltambahpersyaratan = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 18;BA.debugLine="Private pnlPersyaratan As Panel";
tambahdata.mostCurrent._pnlpersyaratan = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 19;BA.debugLine="Private xclv As CustomListView";
tambahdata.mostCurrent._xclv = RemoteObject.createNew ("b4a.example3.customlistview");
 //BA.debugLineNum = 20;BA.debugLine="Private lblpersyaratan As B4XView";
tambahdata.mostCurrent._lblpersyaratan = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper");
 //BA.debugLineNum = 21;BA.debugLine="Private lblfile As B4XView";
tambahdata.mostCurrent._lblfile = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper");
 //BA.debugLineNum = 22;BA.debugLine="Private Button1 As B4XView";
tambahdata.mostCurrent._button1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper");
 //BA.debugLineNum = 23;BA.debugLine="Private Panel1 As B4XView";
tambahdata.mostCurrent._panel1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.B4XViewWrapper");
 //BA.debugLineNum = 24;BA.debugLine="Private search As EditText";
tambahdata.mostCurrent._search = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 25;BA.debugLine="Private txtPersyaratan As EditText";
tambahdata.mostCurrent._txtpersyaratan = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 26;BA.debugLine="Private lblPilihFile As Label";
tambahdata.mostCurrent._lblpilihfile = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 28;BA.debugLine="Dim fd As FileDialog";
tambahdata.mostCurrent._fd = RemoteObject.createNew ("anywheresoftware.b4a.agraham.dialogs.InputDialog.FileDialog");
 //BA.debugLineNum = 30;BA.debugLine="Dim su As StringUtils";
tambahdata.mostCurrent._su = RemoteObject.createNew ("anywheresoftware.b4a.objects.StringUtils");
 //BA.debugLineNum = 31;BA.debugLine="Dim imgstr As String";
tambahdata.mostCurrent._imgstr = RemoteObject.createImmutable("");
 //BA.debugLineNum = 32;BA.debugLine="Dim InputStream1 As InputStream";
tambahdata.mostCurrent._inputstream1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.streams.File.InputStreamWrapper");
 //BA.debugLineNum = 33;BA.debugLine="Dim OutputStream1 As OutputStream";
tambahdata.mostCurrent._outputstream1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper");
 //BA.debugLineNum = 34;BA.debugLine="Dim Buffer() As Byte";
tambahdata._buffer = RemoteObject.createNewArray ("byte", new int[] {0}, new Object[]{});
 //BA.debugLineNum = 35;BA.debugLine="Private btnSave As Button";
tambahdata.mostCurrent._btnsave = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _profil_click() throws Exception{
try {
		Debug.PushSubsStack("Profil_Click (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,121);
if (RapidSub.canDelegate("profil_click")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","profil_click");}
 BA.debugLineNum = 121;BA.debugLine="Private Sub Profil_Click";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 122;BA.debugLine="Activity.Finish";
Debug.ShouldStop(33554432);
tambahdata.mostCurrent._activity.runVoidMethod ("Finish");
 BA.debugLineNum = 123;BA.debugLine="StartActivity(Profile)";
Debug.ShouldStop(67108864);
tambahdata.mostCurrent.__c.runVoidMethod ("StartActivity",tambahdata.processBA,(Object)((tambahdata.mostCurrent._profile.getObject())));
 BA.debugLineNum = 124;BA.debugLine="End Sub";
Debug.ShouldStop(134217728);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _search_enterpressed() throws Exception{
try {
		Debug.PushSubsStack("search_EnterPressed (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,107);
if (RapidSub.canDelegate("search_enterpressed")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","search_enterpressed");}
 BA.debugLineNum = 107;BA.debugLine="Private Sub search_EnterPressed";
Debug.ShouldStop(1024);
 BA.debugLineNum = 108;BA.debugLine="FilterList";
Debug.ShouldStop(2048);
_filterlist();
 BA.debugLineNum = 109;BA.debugLine="End Sub";
Debug.ShouldStop(4096);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _showitem() throws Exception{
try {
		Debug.PushSubsStack("showItem (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,61);
if (RapidSub.canDelegate("showitem")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","showitem");}
int _i = 0;
RemoteObject _p = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
 BA.debugLineNum = 61;BA.debugLine="Sub showItem";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 62;BA.debugLine="ModulKoneksi.koneksi";
Debug.ShouldStop(536870912);
tambahdata.mostCurrent._modulkoneksi.runVoidMethod ("_koneksi" /*RemoteObject*/ ,tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 64;BA.debugLine="xclv.Clear";
Debug.ShouldStop(-2147483648);
tambahdata.mostCurrent._xclv.runVoidMethod ("_clear");
 BA.debugLineNum = 66;BA.debugLine="ModulKoneksi.ResultS = ModulKoneksi.MHandler.Quer";
Debug.ShouldStop(2);
tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/  = RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("mysql.mysqlhandler.ResultSetWrapper"), tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runMethod(false,"Query",(Object)(RemoteObject.createImmutable("SELECT * FROM tb_persyaratan ORDER BY id_persyaratan ASC"))));
 BA.debugLineNum = 68;BA.debugLine="For i = 0 To ModulKoneksi.ResultS.RowCount - 1";
Debug.ShouldStop(8);
{
final int step4 = 1;
final int limit4 = RemoteObject.solve(new RemoteObject[] {tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"RowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step4 > 0 && _i <= limit4) || (step4 < 0 && _i >= limit4) ;_i = ((int)(0 + _i + step4))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 69;BA.debugLine="ModulKoneksi.ResultS.Position  = i";
Debug.ShouldStop(16);
tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 70;BA.debugLine="Dim p As Panel";
Debug.ShouldStop(32);
_p = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");Debug.locals.put("p", _p);
 BA.debugLineNum = 71;BA.debugLine="p = xui.CreatePanel(\"\")";
Debug.ShouldStop(64);
_p = RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.PanelWrapper"), tambahdata.mostCurrent._xui.runMethod(false,"CreatePanel",tambahdata.processBA,(Object)(RemoteObject.createImmutable(""))).getObject());Debug.locals.put("p", _p);
 BA.debugLineNum = 72;BA.debugLine="p.Color = Colors.Transparent";
Debug.ShouldStop(128);
_p.runVoidMethod ("setColor",tambahdata.mostCurrent.__c.getField(false,"Colors").getField(true,"Transparent"));
 BA.debugLineNum = 73;BA.debugLine="p.SetLayoutAnimated(0, 0, 0, xclv.AsView.Width,";
Debug.ShouldStop(256);
_p.runVoidMethod ("SetLayoutAnimated",(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(BA.numberCast(int.class, 0)),(Object)(tambahdata.mostCurrent._xclv.runMethod(false,"_asview").runMethod(true,"getWidth")),(Object)(tambahdata.mostCurrent.__c.runMethod(true,"DipToCurrent",(Object)(BA.numberCast(int.class, 50)))));
 BA.debugLineNum = 74;BA.debugLine="p.LoadLayout(\"Item\")";
Debug.ShouldStop(512);
_p.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("Item")),tambahdata.mostCurrent.activityBA);
 BA.debugLineNum = 76;BA.debugLine="lblpersyaratan.Text = (\"Nama Persyaratan : \" & M";
Debug.ShouldStop(2048);
tambahdata.mostCurrent._lblpersyaratan.runMethod(true,"setText",BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("Nama Persyaratan : "),tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("nama_persyaratan")))))));
 BA.debugLineNum = 77;BA.debugLine="lblfile.Text = (\"File : \" & ModulKoneksi.ResultS";
Debug.ShouldStop(4096);
tambahdata.mostCurrent._lblfile.runMethod(true,"setText",BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("File : "),tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("file_persyaratan")))))));
 BA.debugLineNum = 78;BA.debugLine="Button1.Text = (ModulKoneksi.ResultS.GetString2(";
Debug.ShouldStop(8192);
tambahdata.mostCurrent._button1.runMethod(true,"setText",BA.ObjectToCharSequence((tambahdata.mostCurrent._modulkoneksi._results /*RemoteObject*/ .runMethod(true,"GetString2",(Object)(RemoteObject.createImmutable("id_persyaratan"))))));
 BA.debugLineNum = 79;BA.debugLine="xclv.Add(p, \"\")";
Debug.ShouldStop(16384);
tambahdata.mostCurrent._xclv.runVoidMethod ("_add",RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.objects.B4XViewWrapper"), _p.getObject()),(Object)((RemoteObject.createImmutable(""))));
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 82;BA.debugLine="ModulKoneksi.MHandler.Close";
Debug.ShouldStop(131072);
tambahdata.mostCurrent._modulkoneksi._mhandler /*RemoteObject*/ .runVoidMethod ("Close");
 BA.debugLineNum = 83;BA.debugLine="End Sub";
Debug.ShouldStop(262144);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _simpanblob() throws Exception{
try {
		Debug.PushSubsStack("simpanBlob (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,180);
if (RapidSub.canDelegate("simpanblob")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","simpanblob");}
 BA.debugLineNum = 180;BA.debugLine="Sub simpanBlob";
Debug.ShouldStop(524288);
 BA.debugLineNum = 181;BA.debugLine="InputStream1 = File.OpenInput(fd.FilePath, fd.Cho";
Debug.ShouldStop(1048576);
tambahdata.mostCurrent._inputstream1 = tambahdata.mostCurrent.__c.getField(false,"File").runMethod(false,"OpenInput",(Object)(tambahdata.mostCurrent._fd.runMethod(true,"getFilePath")),(Object)(tambahdata.mostCurrent._fd.runMethod(true,"getChosenName")));
 BA.debugLineNum = 182;BA.debugLine="OutputStream1.InitializeToBytesArray(1000)";
Debug.ShouldStop(2097152);
tambahdata.mostCurrent._outputstream1.runVoidMethod ("InitializeToBytesArray",(Object)(BA.numberCast(int.class, 1000)));
 BA.debugLineNum = 183;BA.debugLine="File.Copy2(InputStream1, OutputStream1)";
Debug.ShouldStop(4194304);
tambahdata.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy2",(Object)((tambahdata.mostCurrent._inputstream1.getObject())),(Object)((tambahdata.mostCurrent._outputstream1.getObject())));
 BA.debugLineNum = 184;BA.debugLine="Buffer = OutputStream1.ToBytesArray";
Debug.ShouldStop(8388608);
tambahdata._buffer = tambahdata.mostCurrent._outputstream1.runMethod(false,"ToBytesArray");
 BA.debugLineNum = 185;BA.debugLine="imgstr = su.EncodeBase64(Buffer)";
Debug.ShouldStop(16777216);
tambahdata.mostCurrent._imgstr = tambahdata.mostCurrent._su.runMethod(true,"EncodeBase64",(Object)(tambahdata._buffer));
 BA.debugLineNum = 186;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _tampilanawal() throws Exception{
try {
		Debug.PushSubsStack("tampilanAwal (tambahdata) ","tambahdata",3,tambahdata.mostCurrent.activityBA,tambahdata.mostCurrent,170);
if (RapidSub.canDelegate("tampilanawal")) { return b4a.example.tambahdata.remoteMe.runUserSub(false, "tambahdata","tampilanawal");}
 BA.debugLineNum = 170;BA.debugLine="Sub tampilanAwal";
Debug.ShouldStop(512);
 BA.debugLineNum = 171;BA.debugLine="txtPersyaratan.Text = \"\"";
Debug.ShouldStop(1024);
tambahdata.mostCurrent._txtpersyaratan.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 172;BA.debugLine="lblPilihFile.Text = \"\"";
Debug.ShouldStop(2048);
tambahdata.mostCurrent._lblpilihfile.runMethod(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 174;BA.debugLine="showItem";
Debug.ShouldStop(8192);
_showitem();
 BA.debugLineNum = 176;BA.debugLine="pnlPersyaratan.Visible = True";
Debug.ShouldStop(32768);
tambahdata.mostCurrent._pnlpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 177;BA.debugLine="pnlTambahPersyaratan.Visible = False";
Debug.ShouldStop(65536);
tambahdata.mostCurrent._pnltambahpersyaratan.runMethod(true,"setVisible",tambahdata.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 178;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}